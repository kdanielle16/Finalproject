# forms.py
from django import forms
from .models import Student, Course


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ('id', 'first_name', 'last_name', 'major', 'year', 'gpa')


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ('id', 'title', 'name', 'section_code', 'department', 'instructor_full_name')
