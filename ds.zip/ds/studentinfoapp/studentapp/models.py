# models.py

from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class Student(models.Model):
    id = models.CharField(max_length=10, primary_key=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    major = models.CharField(max_length=50)
    year = models.IntegerField(choices=[(1, 'Freshman'), (2, 'Sophomore'), (3, 'Junior'), (4, 'Senior')])
    gpa = models.FloatField(validators=[MinValueValidator(0.0), MaxValueValidator(4.0)])

class Course(models.Model):
    id = models.CharField(max_length=10, primary_key=True)
    title = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    section_code = models.CharField(max_length=10)
    department = models.CharField(max_length=50)
    instructor_name = models.CharField(max_length=100)

class Enrollment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('student', 'course')


# forms.py

from django import forms
from .models import Student, Course

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['id', 'first_name', 'last_name', 'major', 'year', 'gpa']

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['id', 'title', 'name', 'section_code', 'department', 'instructor_name']

class EnrollmentForm(forms.ModelForm):
    class Meta:
        model = Enrollment
        fields = ['student', 'course']
